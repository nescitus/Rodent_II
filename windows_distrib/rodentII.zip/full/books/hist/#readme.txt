These books were made using pgn files by Norm Pollock,
downloaded from http://www.hoflink.com/~npollock/40H.html

They are meant to be used in Rodent II chess engine
as main books accompanying player books, so that for example
pre-1930 players don't play openings that look too modern.